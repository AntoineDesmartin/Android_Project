package edu.ihm.vue;

public interface IPictureActivity {
    final int REQUEST_CAMERA=100;
}
